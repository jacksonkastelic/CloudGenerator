import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * Creates a TagCloud given a text file.
 *
 * @author Danny Carrell
 * @author Jackson Kastelic
 * @author Zach Walker
 *
 */
public final class TagCloudGenerator {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private TagCloudGenerator() {
    }

    /**
     * The maximum font size.
     */
    private static final int MAX_FONT_SIZE = 37;

    /**
     * The min font size.
     */
    private static final int MIN_FONT_SIZE = 11;

    /**
     * Compare strings in alphabetical order, ignoring case.
     */
    public static class AlphabeticalOrder implements Comparator<String> {
        @Override
        public int compare(String o1, String o2) {
            return o1.compareToIgnoreCase(o2);
        }
    }

    /**
     * Compare values of a Map in descending numeric order.
     */
    public static class NumericalOrder
            implements Comparator<Map.Entry<String, Integer>> {

        @Override
        public int compare(Map.Entry<String, Integer> o1,
                Map.Entry<String, Integer> o2) {
            return o2.getValue().compareTo(o1.getValue());
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the text to get the next word of
     * @return the first word or separator string found in {@code
     text}  starting at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection
     separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}
     and
     *   (position + |nextWordOrSeparator| = |text|  or
     * entries(text[position, position + |nextWordOrSeparator| +
     1))
     * intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     * entries(text[position, position + |nextWordOrSeparator| +
     1))
     * is not subset of separators)
     * </pre>
     */
    private static String nextWordOrSeparator(String text) {
        int pos = 0;
        String word = "";
        String line = text;
        while (line.length() > 0 && !Character.isLetter(line.charAt(0))) {
            line = line.substring(1, line.length());
        }
        while (pos < line.length() && Character.isLetter(line.charAt(pos))) {
            word = word + line.charAt(pos);
            pos++;

        }
        return word;

    }

    /**
     * Populates a queue with each word found in the text file, counts
     * additional instances of a word and stores in a map.
     *
     * @param file
     *            the inputed file reading object
     * @param words
     *            Contains the words to output
     * @return int array with min and max count
     * @throws IOException
     * @updates words
     * @updates counts
     * @requires file.is_open
     * @ensures words == counts.keys, counts.values has the number of times each
     *          key is repeated.
     *
     */
    private static int[] getWords(BufferedReader file,
            SortedMap<String, Integer> words) throws IOException {

        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;

        //Runs through each line of file to get word counts
        String line = "";
        line = file.readLine();
        while (line != null) {

            boolean stillHasWord = true;
            while (line.length() != 0 && stillHasWord) {

                String word = nextWordOrSeparator(line);
                word = word.toLowerCase();
                line = line.substring(word.length());

                //Gets rid of seperators if they are the intial characters of the line
                stillHasWord = false;
                while (line.length() > 0 && !stillHasWord) {
                    if (Character.isLetter(line.charAt(0))) {
                        stillHasWord = true;
                    } else {
                        line = line.substring(1);
                    }
                }
                //If the word in already in the map, iterates the count
                if (words.containsKey(word)) {
                    words.replace(word, words.get(word) + 1);

                    if (min > words.get(word)) {
                        min = words.get(word);

                    }
                    if (max < words.get(word)) {
                        max = words.get(word);

                    }

                    //Adds word into the map/queue if it is not already
                } else if (!word.isEmpty()
                        && !Character.isDigit(word.charAt(0))) {
                    words.put(word, 1);

                    if (min > 1) {
                        min = 1;
                    }
                    if (max < 1) {
                        max = 1;
                    }

                }

            }
            line = file.readLine();

        }
        int[] ar = new int[] { min, max };
        return ar;

    }

    /**
     * Sorts the elements of the sorting machines.
     *
     * @param numericalSorter
     *            Numerical Comparator
     * @param words
     *            Map that contains all the words
     * @param wordCount
     *            the number of words to display in the TagCloud
     * @param counts
     *            map that stores the number of times a word is repeated
     * @param min
     *            minimum count of any word
     * @param max
     *            maximum count of any word
     */
    public static void sortElements(SortedMap<String, Integer> words,
            ArrayList<Map.Entry<String, Integer>> counts, int wordCount,
            Integer min, Integer max,
            Comparator<Map.Entry<String, Integer>> numericalSorter) {
        while (words.size() != 0) {
            counts.add(new AbstractMap.SimpleEntry<String, Integer>(
                    words.firstKey(), words.remove(words.firstKey())));
        }

        counts.sort(numericalSorter);

        for (int i = 0; i < wordCount; i++) {
            Map.Entry<String, Integer> e = counts.remove(0);
            words.put(e.getKey(), e.getValue());
        }
    }

    /**
     * Generates the HTML output file with the words and their respective
     * counts.
     *
     * @param fileName
     *            the name of the input file
     *
     * @param file
     *            the output HTML file writing object
     * @param numWords
     *            how many words to print out
     * @param words
     *            the alphabetically sorted data structure
     * @param min
     *            the minimum count of words
     * @param max
     *            the maximum count of words
     *
     * @requires file.is_Open, words and counts are populated with respective
     *           values
     * @ensures properly formatted HTML file is exported with a table of words
     *          and values
     *
     */
    private static void generateOutput(String fileName, PrintWriter file,
            SortedMap<String, Integer> words, int numWords, Integer min,
            Integer max) {

        //Header and title
        file.println("<head>");
        file.println("<title>" + "Top " + numWords + " words in " + fileName
                + "</title>");
        file.println(
                "<link href=\"data/tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">");
        file.println(
                "<link href=\"tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">");

        file.println("<style>");
        file.println(
                "div{background-color: lightgrey; width: 700px; margin: 15px;}");
        file.println("</style>");
        file.println("<body>");
        file.println(
                "<h1>" + "Top " + numWords + " words in " + fileName + "</h1>");
        file.println("<hr>");

        //Starts the list
        file.println("<div class = \"cdiv\"><p class=\"cbox\">");

        //Creates a row with word and count for each in queue
        while (words.size() != 0) {
            String word = words.firstKey();
            int count = words.remove(word);
            int scaledNum = 0;
            if (min.compareTo(max) == 0) {
                scaledNum = MIN_FONT_SIZE;
            } else {
                scaledNum = (MAX_FONT_SIZE * (count - min)) / (max - min)
                        + MIN_FONT_SIZE;
            }
            file.println("<span style=\"cursor:default\" class=\"f" + scaledNum
                    + "\" title=\"count: " + count + "\">" + word + "</span>");
        }

        //HTML closers
        file.println("</p></div>");
        file.println("</body>");
        file.println("</html>");
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        BufferedReader in = new BufferedReader(
                new InputStreamReader(System.in));

        //Gets the input file
        System.out.print("Please enter an input file: ");
        String userInFile = null;
        try {
            userInFile = in.readLine();
        } catch (IOException e1) {
            System.err.print("Unable to get input file string.");
        }

        //Gets the output file
        System.out.print("Please enter an output file: ");
        String userOutFile = null;
        try {
            userOutFile = in.readLine();
        } catch (IOException e1) {
            System.err.print("Unable to get output file string.");
        }

        String numberOfWordsStr = "";

        //Creates the objects to interact with provided files
        BufferedReader txtFile = null;
        try {
            txtFile = new BufferedReader(new FileReader(userInFile));
        } catch (FileNotFoundException e1) {
            System.err.print("Unable to open file: " + userInFile);
        }

        PrintWriter htmlFile = null;
        try {
            htmlFile = new PrintWriter(
                    new BufferedWriter(new FileWriter(userOutFile)));
        } catch (IOException e1) {
            System.err.print("Unable to write to file: " + userOutFile);
        }

        //Creates Comparators, SortingMachines and Map for words and counts
        Comparator<String> alphabeticalSorter = new AlphabeticalOrder();
        Comparator<Map.Entry<String, Integer>> numericalSorter = new NumericalOrder();
        SortedMap<String, Integer> words = new TreeMap<>(alphabeticalSorter);
        ArrayList<Map.Entry<String, Integer>> counts = new ArrayList<>();

        //Min and max vals initialization
        int countMin = 0;
        int countMax = 0;

        try {
            int[] ar = getWords(txtFile, words);
            countMin = ar[0];
            countMax = ar[1];
        } catch (IOException e) {
            System.err.print("Error getting words, file issues.");
        }

        //Gets the number of words included
        boolean isNumber = false;
        while (!isNumber) {
            System.out.print("Please enter the number of words to display: ");
            try {
                numberOfWordsStr = in.readLine();
            } catch (IOException e) {
                System.err.print("Unable to get number input.");
            }
            isNumber = true;
            for (int i = 0; i < numberOfWordsStr.length() && isNumber; i++) {
                isNumber = (Character.isDigit(numberOfWordsStr.charAt(i)));
            }

            if (!isNumber) {
                System.out.println("Only positive numbers are allowed.");
            } else if (Integer.parseInt(numberOfWordsStr) > words.size()) {
                System.out.println(
                        "Number needs to be less than or equal to the number of words ("
                                + counts.size() + ").");
                isNumber = false;
            }
        }

        int numWords = Integer.parseInt(numberOfWordsStr);

        //Sorts the elements of the sorting machines
        sortElements(words, counts, numWords, countMin, countMax,
                numericalSorter);

        /*
         * Generates the HTML output file with the words and their respective
         * counts.
         */
        generateOutput(userInFile, htmlFile, words, numWords, countMin,
                countMax);

        /*
         * Close input and output streams
         */
        try {
            in.close();
        } catch (IOException e) {
            System.err.print("Can't close console input.");
        }

        try {
            txtFile.close();
        } catch (IOException e) {
            System.err.print("Can't close file input.");
        }
        htmlFile.close();
    }
}
